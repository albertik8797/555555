﻿public class FoodCategory
{
    public string Name { get; set; }
}
